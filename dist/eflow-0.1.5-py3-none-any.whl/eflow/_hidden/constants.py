from eflow._hidden.general_objects.enum import *

SYS_CONSTANTS = enum(PARENT_OUTPUT_FOLDER_NAME="eflow Data")
GRAPH_DEFAULTS = enum(FIGSIZE=(10, 8))
# FORMATED_STRINGS = enum()
# STRING_CONSTANTS = enum()
