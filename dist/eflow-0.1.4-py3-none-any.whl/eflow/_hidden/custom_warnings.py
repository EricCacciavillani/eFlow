class DataFrameWarning(UserWarning, ValueError):
    pass
